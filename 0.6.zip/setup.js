// ================================================================
// SETUP.JS — настройка ПИнфо (прямая загрузка из walp)
// ================================================================

const BASE_WALP_URL = 'https://kskkbio.w10.site/pinfo/walp/';
const MAX_WALLPAPERS = 30;
const ONBOARDED_KEY = 'csur_onboarded_v1';
const STATE_KEY = 'csur_state';

const SUGGESTED_SITES = {
    yandex:   { name: 'Яндекс',   url: 'https://ya.ru',              icon: 'search' },
    google:   { name: 'Google',   url: 'https://google.com',          icon: 'search' },
    youtube:  { name: 'YouTube',  url: 'https://youtube.com',         icon: 'smart_display' },
    vk:       { name: 'VK',       url: 'https://vk.com',              icon: 'forum' },
    telegram: { name: 'Telegram', url: 'https://web.telegram.org',    icon: 'send' },
    github:   { name: 'GitHub',   url: 'https://github.com',          icon: 'code' },
};

const ICON_OPTIONS = [
    'language','forum','smart_toy','mail','school','smart_display','code','music_note',
    'drafts','folder_open','search','chat','send','headphones','movie','menu_book',
    'translate','cloud','calendar_month','public','star','favorite','bolt','rocket_launch',
    'dashboard','settings','photo_camera','sports_esports','wb_sunny','map','storefront',
];

let state = {
    currentPane: 1,
    userName: '',
    lovesCustomizing: true,
    selectedWallpaper: null,
    selectedAccent: null,
    selectedEffect: 'glass',
    services: [],
    agreedToTerms: false,
    isOnboarded: false,
};

let activeServiceId = null;

function isOnboarded() {
    try {
        if (localStorage.getItem(ONBOARDED_KEY) === '1') return true;
        const raw = localStorage.getItem(STATE_KEY);
        if (!raw) return false;
        const s = JSON.parse(raw);
        return !!(s && s.isOnboarded === true);
    } catch (e) { return false; }
}

function markOnboarded() {
    try {
        localStorage.setItem(ONBOARDED_KEY, '1');
        state.isOnboarded = true;
        localStorage.setItem(STATE_KEY, JSON.stringify(state));
        return true;
    } catch (e) { return false; }
}

(function checkOnboarded() {
    if (isOnboarded()) { window.location.replace('index2.html'); return; }
    try {
        const raw = localStorage.getItem(STATE_KEY);
        if (raw) {
            const s = JSON.parse(raw);
            if (s && typeof s === 'object') state = { ...state, ...s, isOnboarded: false };
        }
    } catch (e) {}
})();

document.addEventListener('DOMContentLoaded', async () => {
    renderAccentGrid();
    renderEffectGrid();
    renderServices();
    renderIconGrid();
    bindEvents();
    updateClock();
    setInterval(updateClock, 1000);
    updateNavigation();

    // Загружаем обои из корня папки walp
    await loadWallpapers();

    if (state.userName) document.getElementById('userNameInput').value = state.userName;
    if (state.agreedToTerms) document.getElementById('agreeCheck').checked = true;
    document.querySelectorAll('input[name="bgEffect"]').forEach(r => {
        if (r.value === state.selectedEffect) r.checked = true;
    });

    if (state.selectedWallpaper) applyPreviewTheme();
    if (state.selectedAccent) applyAccent(state.selectedAccent);
});

function updateClock() {
    const el = document.getElementById('setupClock');
    if (el) el.textContent = new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

// ================================================================
// ПРЯМАЯ ЗАГРУЗКА ОБОЕВ ИЗ walp/
// ================================================================
async function loadWallpapers() {
    const track = document.getElementById('wallpaperCarousel');
    if (!track) return;
    track.innerHTML = '<div class="empty-state" style="padding:20px;">Загрузка обоев...</div>';

    const checks = [];
    for (let i = 1; i <= MAX_WALLPAPERS; i++) {
        checks.push(checkImageExists(`${BASE_WALP_URL}${i}.png`, `${BASE_WALP_URL}${i}.jpg`));
    }
    const results = await Promise.all(checks);
    const validSrcs = results.filter(Boolean);

    track.innerHTML = '';

    if (validSrcs.length === 0) {
        track.innerHTML = '<div class="empty-state" style="padding:20px;">Обои не найдены.<br>Проверьте, что в папке <code>walp</code> есть <code>1.png</code>, <code>2.png</code> и т.д.</div>';
        return;
    }

    validSrcs.forEach((src, idx) => {
        const item = document.createElement('div');
        item.className = 'carousel-item';
        if (state.selectedWallpaper === src) item.classList.add('selected');
        item.dataset.src = src;
        item.dataset.index = idx;

        const img = document.createElement('img');
        img.src = src;
        img.loading = 'lazy';

        const check = document.createElement('span');
        check.className = 'material-icons check-icon';
        check.textContent = 'check';

        item.appendChild(img);
        item.appendChild(check);

        item.addEventListener('click', () => {
            state.selectedWallpaper = src;
            saveState();
            track.querySelectorAll('.carousel-item').forEach(el => el.classList.remove('selected'));
            item.classList.add('selected');
            applyPreviewTheme();
            updateNavigation();
        });

        track.appendChild(item);
    });

    if (!state.selectedWallpaper && validSrcs.length > 0) {
        track.querySelector('.carousel-item').click();
    }

    const prevBtn = document.getElementById('wallpaperPrev');
    const nextBtn = document.getElementById('wallpaperNext');
    const newPrev = prevBtn.cloneNode(true);
    const newNext = nextBtn.cloneNode(true);
    prevBtn.parentNode.replaceChild(newPrev, prevBtn);
    nextBtn.parentNode.replaceChild(newNext, nextBtn);
    newPrev.addEventListener('click', () => scrollCarousel(-1));
    newNext.addEventListener('click', () => scrollCarousel(1));
}

function checkImageExists(pngSrc, jpgSrc) {
    return new Promise(resolve => {
        const img = new Image();
        img.onload = () => resolve(pngSrc);
        img.onerror = () => {
            const img2 = new Image();
            img2.onload = () => resolve(jpgSrc);
            img2.onerror = () => resolve(null);
            img2.src = jpgSrc;
        };
        img.src = pngSrc;
    });
}

function scrollCarousel(dir) {
    const track = document.getElementById('wallpaperCarousel');
    if (!track) return;
    const item = track.querySelector('.carousel-item');
    const step = item ? item.offsetWidth + 14 : 234;
    track.scrollBy({ left: step * dir, behavior: 'smooth' });
}

function applyPreviewTheme() {
    if (state.selectedWallpaper) {
        document.documentElement.style.setProperty('--bg-image', `url(${state.selectedWallpaper})`);
    }
}

// ================================================================
// АКЦЕНТЫ
// ================================================================
function getAccentPalette() {
    return ['#D0BCFF','#FFB4AB','#FFD8E4','#EFB8C8','#CCC2DC','#B8E6C8','#B8D4E6','#E6D8B8','#E6B8B8','#C8B8E6'];
}

function renderAccentGrid() {
    const c = document.getElementById('accentGrid');
    if (!c) return;
    c.innerHTML = '';
    getAccentPalette().forEach(color => {
        const el = document.createElement('div');
        el.className = 'accent-item';
        el.style.background = color;
        if (state.selectedAccent === color) el.classList.add('selected');
        el.innerHTML = '<span class="material-icons check-icon">check</span>';
        el.addEventListener('click', () => {
            state.selectedAccent = color;
            saveState();
            c.querySelectorAll('.accent-item').forEach(x => x.classList.remove('selected'));
            el.classList.add('selected');
            applyAccent(color);
            updateNavigation();
        });
        c.appendChild(el);
    });
}

function applyAccent(hex) {
    const p = generateTonalPalette(hex);
    const r = document.documentElement;
    const set = (k, v) => r.style.setProperty(k, v);
    set('--md-primary', p.primary); set('--md-on-primary', p.onPrimary);
    set('--md-primary-container', p.primaryContainer); set('--md-on-primary-container', p.onPrimaryContainer);
    set('--md-secondary', p.secondary); set('--md-secondary-container', p.secondaryContainer);
    set('--md-on-secondary-container', p.onSecondaryContainer); set('--md-tertiary', p.tertiary);
    set('--md-tertiary-container', p.tertiaryContainer); set('--md-on-tertiary-container', p.onTertiaryContainer);
    set('--md-surface', p.surface); set('--md-on-surface', p.onSurface);
    set('--md-surface-variant', p.surfaceVariant); set('--md-on-surface-variant', p.onSurfaceVariant);
    set('--md-outline', p.outline); set('--md-outline-variant', p.outlineVariant);
    set('--md-surface-container', p.surfaceContainer); set('--md-surface-container-high', p.surfaceContainerHigh);
    set('--md-surface-container-highest', p.surfaceContainerHighest); set('--md-error-container', p.errorContainer);
    set('--md-on-error-container', p.onErrorContainer);
}

function renderEffectGrid() {
    document.querySelectorAll('input[name="bgEffect"]').forEach(r => {
        r.checked = r.value === state.selectedEffect;
        r.addEventListener('change', () => {
            state.selectedEffect = r.value;
            saveState();
            document.body.dataset.bgEffect = state.selectedEffect;
        });
    });
    document.body.dataset.bgEffect = state.selectedEffect;
}

// ================================================================
// СЕРВИСЫ
// ================================================================
function renderServices() {
    const c = document.getElementById('servicesList');
    if (!c) return;
    c.innerHTML = '';
    if (state.services.length === 0) {
        c.innerHTML = '<div class="empty-state" style="padding:16px;">Пока ничего не добавлено</div>';
        return;
    }
    state.services.forEach(svc => {
        const row = document.createElement('div');
        row.className = 'service-row';
        if (activeServiceId === svc.id) row.classList.add('active');

        const iconBtn = document.createElement('div');
        iconBtn.className = 'service-icon-btn';
        iconBtn.innerHTML = `<span class="material-icons">${svc.icon}</span>`;

        const info = document.createElement('div');
        info.className = 'service-info';
        const nameEl = document.createElement('div');
        nameEl.className = 'service-name-setup';
        nameEl.textContent = svc.name;
        const urlEl = document.createElement('div');
        urlEl.className = 'service-url-setup';
        try { urlEl.textContent = new URL(svc.url).hostname; } catch(e) { urlEl.textContent = svc.url; }
        info.appendChild(nameEl);
        info.appendChild(urlEl);

        const del = document.createElement('button');
        del.className = 'delete-service-btn';
        del.innerHTML = '<span class="material-icons" style="font-size:18px;">close</span>';
        del.addEventListener('click', (e) => {
            e.stopPropagation();
            state.services = state.services.filter(s => s.id !== svc.id);
            if (activeServiceId === svc.id) activeServiceId = null;
            saveState();
            renderServices();
            updateNavigation();
        });

        row.appendChild(iconBtn); row.appendChild(info); row.appendChild(del);
        row.addEventListener('click', () => { activeServiceId = svc.id; renderServices(); });
        c.appendChild(row);
    });
}

function renderIconGrid() {
    const c = document.getElementById('iconGrid');
    if (!c) return;
    c.innerHTML = '';
    ICON_OPTIONS.forEach(icon => {
        const el = document.createElement('div');
        el.className = 'icon-option';
        el.innerHTML = `<span class="material-icons">${icon}</span>`;
        el.addEventListener('click', () => {
            if (!activeServiceId && state.services.length > 0) activeServiceId = state.services[0].id;
            const svc = state.services.find(s => s.id === activeServiceId);
            if (!svc) return;
            svc.icon = icon; saveState(); renderServices();
            c.querySelectorAll('.icon-option').forEach(x => x.classList.remove('selected'));
            el.classList.add('selected');
        });
        c.appendChild(el);
    });
}

function addService(url, name, icon = 'language') {
    url = (url || '').trim();
    if (!url) return false;
    if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
    try { new URL(url); } catch(e) { return false; }
    if (state.services.length >= 9) { alert('Максимум 9 сервисов'); return false; }
    let finalName = (name || '').trim() || url.replace(/^https?:\/\/(www\.)?/, '').split('/')[0];
    state.services.push({ id: 'svc_' + Date.now(), name: finalName, url, icon });
    activeServiceId = state.services[state.services.length - 1].id;
    saveState(); renderServices(); updateNavigation();
    return true;
}

// ================================================================
// НАВИГАЦИЯ
// ================================================================
function goNext() { if (state.currentPane < 7 && isPaneValid(state.currentPane)) { state.currentPane++; saveState(); updateNavigation(); } }
function goBack() { if (state.currentPane > 1) { state.currentPane--; saveState(); updateNavigation(); } }

function updateNavigation() {
    document.querySelectorAll('.setup-pane').forEach(p => p.classList.toggle('active', parseInt(p.dataset.pane) === state.currentPane));
    const backBtn = document.getElementById('backBtn');
    backBtn.style.visibility = state.currentPane === 1 ? 'hidden' : 'visible';
    const nextBtn = document.getElementById('nextBtn');
    if (state.currentPane === 7) nextBtn.style.display = 'none';
    else { nextBtn.style.display = 'inline-flex'; nextBtn.disabled = !isPaneValid(state.currentPane); }
    const stage = getStageForPane(state.currentPane);
    document.querySelectorAll('.setup-step').forEach(el => {
        const s = parseInt(el.dataset.stage);
        el.classList.toggle('active', s === stage);
        el.classList.toggle('done', s < stage);
    });
    document.getElementById('setupProgressBar').style.width = ((state.currentPane - 1) / 6) * 100 + '%';
}

function isPaneValid(pane) {
    switch (pane) {
        case 1: return state.userName.trim().length >= 1;
        case 2: return true;
        case 3: return state.selectedWallpaper !== null;
        case 4: return state.selectedAccent !== null;
        case 5: return state.services.length >= 1;
        case 6: return state.agreedToTerms;
        default: return true;
    }
}

function getStageForPane(pane) {
    if (pane === 1) return 1;
    if (pane >= 2 && pane <= 5) return 2;
    if (pane === 6) return 3;
    return 4;
}

function bindEvents() {
    const nameInput = document.getElementById('userNameInput');
    nameInput.addEventListener('input', () => { state.userName = nameInput.value.trim(); saveState(); updateNavigation(); });
    document.getElementById('nextBtn').addEventListener('click', goNext);
    document.getElementById('backBtn').addEventListener('click', goBack);
    document.getElementById('launchBtn').addEventListener('click', () => { markOnboarded(); window.location.href = 'index2.html'; });

    document.querySelectorAll('input[name="personalize"]').forEach(r => r.addEventListener('change', () => {
        if (r.value === 'ok') document.getElementById('stubbornModal').classList.add('show');
    }));
    document.getElementById('closeStubbornModal').addEventListener('click', () => {
        document.getElementById('stubbornModal').classList.remove('show');
        document.querySelectorAll('input[name="personalize"]').forEach(r => r.checked = r.value === 'love');
    });

    document.getElementById('agreeCheck').addEventListener('change', function() {
        if (this.checked) document.getElementById('disagreeCheck').checked = false;
        state.agreedToTerms = this.checked; saveState(); updateNavigation();
    });
    document.getElementById('disagreeCheck').addEventListener('change', function() {
        if (this.checked) document.getElementById('agreeCheck').checked = false;
        state.agreedToTerms = false; saveState(); updateNavigation();
    });

    document.getElementById('addServiceBtn').addEventListener('click', () => {
        const url = document.getElementById('newServiceUrl').value;
        const name = document.getElementById('newServiceName').value;
        if (addService(url, name)) {
            document.getElementById('newServiceUrl').value = '';
            document.getElementById('newServiceName').value = '';
        }
    });

    document.querySelectorAll('.chip[data-suggest]').forEach(chip => {
        chip.addEventListener('click', () => {
            const data = SUGGESTED_SITES[chip.dataset.suggest];
            if (data) addService(data.url, data.name, data.icon);
        });
    });
}

function saveState() { try { localStorage.setItem(STATE_KEY, JSON.stringify(state)); } catch(e) {} }

// Цветовые утилиты
function hexToHsl(hex) {
    hex = hex.replace('#', '');
    const r = parseInt(hex.substring(0,2),16)/255, g = parseInt(hex.substring(2,4),16)/255, b = parseInt(hex.substring(4,6),16)/255;
    const max = Math.max(r,g,b), min = Math.min(r,g,b); let h, s, l = (max+min)/2;
    if (max === min) { h = s = 0; } else {
        const d = max - min; s = l > .5 ? d/(2-max-min) : d/(max+min);
        switch (max) { case r: h = ((g-b)/d + (g<b?6:0))/6; break; case g: h = ((b-r)/d + 2)/6; break; case b: h = ((r-g)/d + 4)/6; break; }
    }
    return { h: h*360, s: s*100, l: l*100 };
}
function hslToHex(h, s, l) {
    h = ((h%360)+360)%360; s = Math.max(0, Math.min(100, s))/100; l = Math.max(0, Math.min(100, l))/100;
    const c = (1 - Math.abs(2*l - 1))*s, x = c * (1 - Math.abs((h/60)%2 - 1)), m = l - c/2;
    let r, g, b;
    if (h < 60) { r = c; g = x; b = 0; } else if (h < 120) { r = x; g = c; b = 0; } else if (h < 180) { r = 0; g = c; b = x; } else if (h < 240) { r = 0; g = x; b = c; } else if (h < 300) { r = x; g = 0; b = c; } else { r = c; g = 0; b = x; }
    const toHex = v => { const hh = Math.round((v+m)*255).toString(16); return hh.length === 1 ? '0' + hh : hh; };
    return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}
function generateTonalPalette(hex) {
    const { h, s } = hexToHsl(hex); const c = (h, s, l) => hslToHex(h, s, l);
    return {
        primary: c(h, Math.min(s*.8, 80), 75), onPrimary: c(h, Math.min(s*.9, 60), 20),
        primaryContainer: c(h, Math.min(s*.7, 60), 35), onPrimaryContainer: c(h, Math.min(s*.6, 50), 90),
        secondary: c(h+20, Math.min(s*.3, 40), 75), secondaryContainer: c(h+20, Math.min(s*.3, 35), 35),
        onSecondaryContainer: c(h+20, Math.min(s*.2, 30), 90), tertiary: c(h-30, Math.min(s*.5, 60), 75),
        tertiaryContainer: c(h-30, Math.min(s*.4, 45), 35), onTertiaryContainer: c(h-30, Math.min(s*.3, 40), 90),
        surface: c(h, Math.min(s*.1, 10), 8), onSurface: c(h, Math.min(s*.1, 15), 90),
        surfaceVariant: c(h, Math.min(s*.1, 15), 25), onSurfaceVariant: c(h, Math.min(s*.1, 15), 75),
        outline: c(h, Math.min(s*.1, 15), 55), outlineVariant: c(h, Math.min(s*.1, 15), 35),
        surfaceContainer: c(h, Math.min(s*.1, 10), 14), surfaceContainerHigh: c(h, Math.min(s*.1, 10), 18),
        surfaceContainerHighest: c(h, Math.min(s*.1, 10), 22), errorContainer: c(0, 60, 30), onErrorContainer: c(0, 70, 90),
    };
}