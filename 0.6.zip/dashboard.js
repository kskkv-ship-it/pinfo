// ================================================================
// DASHBOARD.JS — ПИнфо
// ================================================================

const BASE_WALP_URL = 'https://kskkbio.w10.site/pinfo/walp/';
const ONBOARDED_KEY = 'csur_onboarded_v1';
const STATE_KEY = 'csur_state';
const SOUND_URL = 'https://kskkbio.w10.site/pinfo/sound.mp3';

let state = null;
let todos = [];
let currentView = 'dashboard';
let timerInterval = null;
let timerSeconds = 0;

function isOnboarded() {
    try { return localStorage.getItem(ONBOARDED_KEY) === '1'; } catch(e) { return false; }
}

(function check() {
    if (!isOnboarded()) { window.location.replace('index.html'); return; }
    try { state = JSON.parse(localStorage.getItem(STATE_KEY) || '{}'); } catch(e) { state = { isOnboarded: true }; }
})();

document.addEventListener('DOMContentLoaded', function() {
    if (!state) return;
    applyTheme();

    setTimeout(() => {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) { overlay.classList.add('hidden'); document.getElementById('dashboardContent').style.display = 'block'; setTimeout(() => overlay.remove(), 700); }

        updateGreeting();
        updateDateTime();
        setInterval(updateDateTime, 1000);

        setTimeout(() => {
            document.querySelectorAll('.pre-fade').forEach(el => el.classList.add('visible'));
            renderServices();
            loadTodos();
            renderTodosV2();
            loadWeather();
            renderCalendar();
            initPhotoWidget();
            initSettingsPanel();
            bindEvents();
            renderStats();
        }, 1300);
    }, 1400);
});

function applyTheme() {
    if (state.selectedWallpaper) document.documentElement.style.setProperty('--bg-image', `url(${state.selectedWallpaper})`);
    document.body.dataset.bgEffect = state.selectedEffect || 'glass';
    if (state.selectedAccent) applyAccent(state.selectedAccent);
}

function applyAccent(hex) {
    const p = generateTonalPalette(hex);
    const r = document.documentElement;
    const set = (k, v) => r.style.setProperty(k, v);
    set('--md-primary', p.primary); set('--md-on-primary', p.onPrimary);
    set('--md-primary-container', p.primaryContainer); set('--md-on-primary-container', p.onPrimaryContainer);
    set('--md-secondary', p.secondary); set('--md-secondary-container', p.secondaryContainer);
    set('--md-on-secondary-container', p.onSecondaryContainer); set('--md-tertiary', p.tertiary);
    set('--md-tertiary-container', p.tertiaryContainer); set('--md-on-tertiary-container', p.onTertiaryContainer);
    set('--md-surface', p.surface); set('--md-on-surface', p.onSurface);
    set('--md-surface-variant', p.surfaceVariant); set('--md-on-surface-variant', p.onSurfaceVariant);
    set('--md-outline', p.outline); set('--md-outline-variant', p.outlineVariant);
    set('--md-surface-container', p.surfaceContainer); set('--md-surface-container-high', p.surfaceContainerHigh);
    set('--md-surface-container-highest', p.surfaceContainerHighest); set('--md-error-container', p.errorContainer);
    set('--md-on-error-container', p.onErrorContainer);
}

function updateDateTime() {
    const now = new Date();
    const dd = String(now.getDate()).padStart(2, '0'), mm = String(now.getMonth() + 1).padStart(2, '0'), yyyy = now.getFullYear();
    const hDate = document.getElementById('headerDate'), hTime = document.getElementById('headerTime');
    if (hDate) hDate.textContent = `${dd}.${mm}.${yyyy}`;
    if (hTime) hTime.textContent = now.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    
    const stageClock = document.getElementById('stageClock'), stageDate = document.getElementById('stageClockDate'), stageDay = document.getElementById('stageClockDay');
    if (stageClock) stageClock.textContent = now.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    if (stageDate) stageDate.textContent = now.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' });
    if (stageDay) stageDay.textContent = now.toLocaleDateString('ru-RU', { weekday: 'long' });
}

function updateGreeting() {
    if (!state) return;
    const hour = new Date().getHours();
    let g = 'Добрый день';
    if (hour < 6) g = 'Доброй ночи'; else if (hour < 12) g = 'Доброе утро'; else if (hour < 18) g = 'Добрый день'; else g = 'Добрый вечер';
    const line1 = document.getElementById('greetingLine1'), name = document.getElementById('greetingName');
    if (line1) line1.textContent = g + ',';
    if (name) name.textContent = state.userName || 'друг';
}

function switchView(viewName) {
    currentView = viewName;
    document.querySelectorAll('.stage-view').forEach(v => v.classList.remove('active'));
    const target = document.getElementById('view' + viewName.charAt(0).toUpperCase() + viewName.slice(1));
    if (target) target.classList.add('active');
    document.querySelectorAll('.function-btn[data-view]').forEach(btn => btn.classList.toggle('active', btn.dataset.view === viewName));
}

async function loadWeather() {
    const c = document.getElementById('weatherWidget');
    if (!c) return;
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);
        const url = `https://api.open-meteo.com/v1/forecast?latitude=55.75&longitude=37.61&current_weather=true`;
        const resp = await fetch(url, { signal: controller.signal });
        clearTimeout(timeoutId);
        const data = await resp.json();
        const cw = data.current_weather;
        const info = getWeatherInfo(cw.weathercode);
        c.innerHTML = `<span class="material-icons weather-icon">${info.icon}</span><span class="weather-temp-inline">${Math.round(cw.temperature)}°</span><span class="weather-desc-inline">${info.desc}</span>`;
    } catch (e) {
        c.innerHTML = `<span class="material-icons weather-icon">cloud_off</span><span class="weather-temp-inline">--°</span><span class="weather-desc-inline">Нет данных</span>`;
    }
}

function getWeatherInfo(code) {
    const map = { 0:'wb_sunny',1:'wb_sunny',2:'cloud',3:'cloud',45:'foggy',61:'umbrella',63:'umbrella',65:'umbrella',71:'ac_unit',73:'ac_unit',75:'ac_unit',95:'thunderstorm' };
    const descs = { 0:'Ясно',1:'Малооблачно',2:'Облачно',3:'Пасмурно',45:'Туман',61:'Дождь',63:'Дождь',65:'Ливень',71:'Снег',73:'Снег',75:'Снегопад',95:'Гроза' };
    return { icon: map[code] || 'wb_sunny', desc: descs[code] || 'Погода' };
}

function renderServices() {
    const c = document.getElementById('servicesGridV2');
    if (!c) return;
    c.innerHTML = '';
    const services = (state && state.services) || [];
    if (services.length === 0) { c.innerHTML = '<div class="services-empty">Здесь появятся ваши сервисы</div>'; return; }
    services.forEach(svc => {
        const a = document.createElement('a');
        a.className = 'service-tile'; a.href = svc.url; a.target = '_blank'; a.rel = 'noopener'; a.title = svc.name;
        a.innerHTML = `<div class="service-tile-icon"><span class="material-icons">${svc.icon || 'language'}</span></div><div class="service-tile-name">${svc.name}</div>`;
        c.appendChild(a);
    });
}

// ================================================================
// СПИСОК ДЕЛ (СЧЕТЧИК)
// ================================================================
function loadTodos() { try { const s = localStorage.getItem('csur_todos'); if (s) todos = JSON.parse(s); } catch(e) { todos = []; } }
function saveTodos() { localStorage.setItem('csur_todos', JSON.stringify(todos)); }

function updateTodoCounter() {
    const input = document.getElementById('todoInputV2');
    const counter = document.getElementById('todoCharCounter');
    if (input && counter) counter.textContent = `${input.value.length}/100`;
}

function addTodo() {
    const i = document.getElementById('todoInputV2');
    if (!i) return;
    const t = i.value.trim();
    if (!t || t.length > 100) return;
    todos.push({ id: Date.now(), text: t, done: false });
    i.value = ''; updateTodoCounter(); saveTodos(); renderTodosV2(); renderStats();
}

function toggleTodo(id) { const t = todos.find(x => x.id === id); if (t) { t.done = !t.done; saveTodos(); renderTodosV2(); renderStats(); } }
function deleteTodo(id) { todos = todos.filter(t => t.id !== id); saveTodos(); renderTodosV2(); renderStats(); }

function renderTodosV2() {
    const c = document.getElementById('todoListV2');
    if (!c) return;
    if (todos.length === 0) { c.innerHTML = '<div class="empty-state">нет дел</div>'; return; }
    c.innerHTML = todos.slice(0, 8).map(t => `
        <li class="todo-item-v2 ${t.done ? 'done' : ''}">
            <input type="checkbox" ${t.done ? 'checked' : ''} data-toggle="${t.id}">
            <span class="todo-text-v2">${escapeHtml(t.text)}</span>
            <button class="todo-del-v2" data-del="${t.id}">✕</button>
            <div class="todo-char-info">${t.text.length}/100</div>
        </li>
    `).join('');
    c.querySelectorAll('[data-toggle]').forEach(el => el.addEventListener('change', () => toggleTodo(parseInt(el.dataset.toggle))));
    c.querySelectorAll('[data-del]').forEach(el => el.addEventListener('click', (e) => { e.stopPropagation(); deleteTodo(parseInt(el.dataset.del)); }));
}

function escapeHtml(s) { return s.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]); }

function renderStats() {
    const c = document.getElementById('stageStats');
    if (!c) return;
    const total = todos.length, done = todos.filter(t => t.done).length, left = total - done;
    const progress = total > 0 ? Math.round(done / total * 100) : 0;
    c.innerHTML = `
        <div class="stage-stat-card"><div class="stage-stat-value">${total}</div><div class="stage-stat-label">Всего дел</div></div>
        <div class="stage-stat-card"><div class="stage-stat-value">${done}</div><div class="stage-stat-label">Выполнено</div></div>
        <div class="stage-stat-card"><div class="stage-stat-value">${left}</div><div class="stage-stat-label">Осталось</div></div>
        <div class="stage-stat-card"><div class="stage-stat-value">${progress}%</div><div class="stage-stat-label">Прогресс</div></div>
    `;
}

// ================================================================
// ТАЙМЕР
// ================================================================
function startTimer() {
    const input = document.getElementById('timerMinutes');
    const mins = parseInt(input.value);
    if (!mins || mins < 1 || mins > 180) return;
    timerSeconds = mins * 60;
    document.getElementById('timerSetup').style.display = 'none';
    document.getElementById('timerRunning').style.display = 'flex';
    updateTimerDisplay();
    
    timerInterval = setInterval(() => {
        timerSeconds--;
        if (timerSeconds <= 0) {
            clearInterval(timerInterval);
            document.getElementById('timerRunning').style.display = 'none';
            document.getElementById('timerSetup').style.display = 'flex';
            const audio = new Audio(SOUND_URL);
            audio.play().catch(e => console.warn('Звук:', e));
            alert('Время вышло!');
        } else {
            updateTimerDisplay();
        }
    }, 1000);
}

function updateTimerDisplay() {
    const m = Math.floor(timerSeconds / 60).toString().padStart(2, '0');
    const s = (timerSeconds % 60).toString().padStart(2, '0');
    document.getElementById('timerDisplay').textContent = `${m}:${s}`;
}

function stopTimer() {
    clearInterval(timerInterval);
    document.getElementById('timerRunning').style.display = 'none';
    document.getElementById('timerSetup').style.display = 'flex';
}

// ================================================================
// КАЛЕНДАРЬ
// ================================================================
function renderCalendar() {
    const c = document.getElementById('calendarWidget');
    if (!c) return;
    const now = new Date(), year = now.getFullYear(), month = now.getMonth(), today = now.getDate();
    const monthNames = ['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
    const dayNames = ['Пн','Вт','Ср','Чт','Пт','Сб','Вс'];
    let startDay = new Date(year, month, 1).getDay(); if (startDay === 0) startDay = 7; startDay -= 1;
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    let html = `<div class="calendar-header"><div class="calendar-month">${monthNames[month]} ${year}</div></div><div class="calendar-grid">${dayNames.map(d => `<div class="calendar-day-name">${d}</div>`).join('')}`;
    for (let i = 0; i < startDay; i++) html += '<div class="calendar-day empty"></div>';
    for (let d = 1; d <= daysInMonth; d++) html += `<div class="calendar-day ${d === today ? 'today' : ''}">${d}</div>`;
    html += '</div>';
    c.innerHTML = html;
}

// ================================================================
// ФОТО
// ================================================================
function initPhotoWidget() {
    const input = document.getElementById('ticketPhotoInput');
    const widget = document.getElementById('photoWidget');
    const panel = document.getElementById('photoPanel');
    if (!input || !widget) return;
    const saved = localStorage.getItem('csur_ticket_photo');
    if (saved) { widget.style.backgroundImage = `url(${saved})`; widget.classList.add('has-photo'); if (panel) panel.classList.add('no-header'); }
    widget.addEventListener('click', () => input.click());
    input.addEventListener('change', (e) => {
        const file = e.target.files[0]; if (!file) return;
        const reader = new FileReader();
        reader.onload = (ev) => {
            widget.style.backgroundImage = `url(${ev.target.result})`; widget.classList.add('has-photo'); if (panel) panel.classList.add('no-header');
            try { localStorage.setItem('csur_ticket_photo', ev.target.result); } catch(e) {}
        };
        reader.readAsDataURL(file);
    });
}

// ================================================================
// РЕДАКТОР ЯРЛЫКОВ
// ================================================================
function initEditLinks() {
    const modal = document.getElementById('editLinksModal');
    const closeBtn = document.getElementById('closeEditLinksModal');
    const editBtn = document.getElementById('editLinksBtn');
    const list = document.getElementById('editLinksList');
    const saveBtn = document.getElementById('saveNewLinkBtn');
    if (!modal || !editBtn) return;

    const renderList = () => {
        list.innerHTML = '';
        state.services.forEach((svc, idx) => {
            const div = document.createElement('div');
            div.style.cssText = 'display:flex; flex-direction:column; gap:8px; background:var(--md-surface-container); padding:12px; border-radius:8px;';
            
            div.innerHTML = `
                <div style="display:flex; gap:8px;">
                    <input type="text" class="setup-input setup-input-compact" style="flex:1;" value="${svc.name}" data-idx="${idx}" data-field="name" placeholder="Название">
                    <input type="text" class="setup-input setup-input-compact" style="flex:1;" value="${svc.url}" data-idx="${idx}" data-field="url" placeholder="URL">
                </div>
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <button class="md-btn md-btn-outlined" style="height:32px; font-size:12px; padding:0 12px;" data-idx="${idx}" data-action="icon">
                        <span class="material-icons" style="font-size:16px;">${svc.icon || 'language'}</span> Иконка
                    </button>
                    <button class="md-btn md-btn-text" style="color:var(--md-error); height:32px; font-size:12px; padding:0 12px;" data-idx="${idx}" data-action="delete">
                        Удалить
                    </button>
                </div>
            `;
            
            list.appendChild(div);
        });

        list.querySelectorAll('input').forEach(input => {
            input.addEventListener('change', (e) => {
                const idx = parseInt(e.target.dataset.idx);
                const field = e.target.dataset.field;
                if (field === 'name') state.services[idx].name = e.target.value;
                if (field === 'url') state.services[idx].url = e.target.value;
                saveState();
                renderServices();
            });
        });

        list.querySelectorAll('[data-action="delete"]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const idx = parseInt(e.currentTarget.dataset.idx);
                state.services.splice(idx, 1);
                saveState();
                renderServices();
                renderList();
            });
        });

        list.querySelectorAll('[data-action="icon"]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const idx = parseInt(e.currentTarget.dataset.idx);
                const icons = ['language','forum','smart_toy','mail','search','code'];
                const current = state.services[idx].icon || 'language';
                const nextIdx = (icons.indexOf(current) + 1) % icons.length;
                state.services[idx].icon = icons[nextIdx];
                saveState();
                renderServices();
                renderList();
            });
        });
    };

    editBtn.addEventListener('click', () => { renderList(); modal.classList.add('show'); });
    closeBtn.addEventListener('click', () => modal.classList.remove('show'));
    
    saveBtn.addEventListener('click', () => {
        const name = document.getElementById('editLinkName').value;
        const url = document.getElementById('editLinkUrl').value;
        if (!name || !url) return;
        state.services.push({ id: 'svc_' + Date.now(), name: name, url: url, icon: 'language' });
        saveState();
        renderServices();
        renderList();
        document.getElementById('editLinkName').value = '';
        document.getElementById('editLinkUrl').value = '';
    });
}

// ================================================================
// СОБЫТИЯ И НАСТРОЙКИ
// ================================================================
function bindEvents() {
    const addBtn = document.getElementById('addTodoV2');
    const input = document.getElementById('todoInputV2');
    if (addBtn) addBtn.addEventListener('click', addTodo);
    if (input) {
        input.addEventListener('keypress', e => { if (e.key === 'Enter') addTodo(); });
        input.addEventListener('input', updateTodoCounter);
    }

    document.getElementById('fnDashboard').addEventListener('click', () => switchView('dashboard'));
    document.getElementById('fnClock').addEventListener('click', () => switchView('clock'));
    document.getElementById('fnStats').addEventListener('click', () => switchView('stats'));
    document.getElementById('fnTimer').addEventListener('click', () => switchView('timer'));

    document.getElementById('startTimerBtn').addEventListener('click', startTimer);
    document.getElementById('stopTimerBtn').addEventListener('click', stopTimer);

    document.getElementById('fullscreenClockBtn').addEventListener('click', () => {
        const el = document.getElementById('clockPanel');
        if (el.requestFullscreen) el.requestFullscreen();
    });

    const settingsBtn = document.getElementById('settingsBtn');
    const settingsPanel = document.getElementById('settingsPanel');
    const closeSettings = document.getElementById('closeSettings');
    if (settingsBtn && settingsPanel) settingsBtn.addEventListener('click', (e) => { e.stopPropagation(); settingsPanel.classList.toggle('open'); });
    if (closeSettings && settingsPanel) closeSettings.addEventListener('click', () => settingsPanel.classList.remove('open'));
    
    document.addEventListener('click', (e) => {
        if (!settingsPanel || !settingsPanel.classList.contains('open')) return;
        const wrapper = document.querySelector('.settings-wrapper');
        if (wrapper && !wrapper.contains(e.target)) settingsPanel.classList.remove('open');
    });

    document.getElementById('resetBtn').addEventListener('click', () => {
        if (confirm('Сбросить всё?')) { localStorage.clear(); window.location.href = 'index.html'; }
    });

    initEditLinks();
}

function initSettingsPanel() {
    const track = document.getElementById('settingsWallpaperCarousel');
    if (!track) return;
    track.innerHTML = '<div style="padding:8px; font-size:11px; opacity:.6;">Загрузка...</div>';

    const checks = [];
    for (let i = 1; i <= 30; i++) {
        checks.push(checkImageExists(`${BASE_WALP_URL}${i}.png`, `${BASE_WALP_URL}${i}.jpg`));
    }
    Promise.all(checks).then(results => {
        const validSrcs = results.filter(Boolean);
        track.innerHTML = '';
        
        if (validSrcs.length === 0) {
            track.innerHTML = '<div style="padding:8px; font-size:11px; opacity:.6;">Нет обоев</div>';
            return;
        }

        validSrcs.forEach(src => {
            const div = document.createElement('div');
            div.className = 'wallpaper-item';
            if (state.selectedWallpaper === src) div.classList.add('selected');
            const img = document.createElement('img');
            img.src = src;
            img.loading = 'lazy';
            div.appendChild(img);
            div.addEventListener('click', () => {
                state.selectedWallpaper = src;
                saveState();
                applyTheme();
                track.querySelectorAll('.wallpaper-item').forEach(x => x.classList.remove('selected'));
                div.classList.add('selected');
            });
            track.appendChild(div);
        });
    });

    document.getElementById('settingsWpPrev').addEventListener('click', () => track.scrollBy({ left: -100, behavior: 'smooth' }));
    document.getElementById('settingsWpNext').addEventListener('click', () => track.scrollBy({ left: 100, behavior: 'smooth' }));

    const acc = document.getElementById('settingsAccentGrid');
    if (acc) {
        acc.innerHTML = '';
        ['#D0BCFF','#FFB4AB','#FFD8E4','#EFB8C8','#CCC2DC','#B8E6C8','#B8D4E6','#E6D8B8'].forEach(c => {
            const div = document.createElement('div');
            div.className = 'accent-item';
            div.style.background = c;
            if (state.selectedAccent === c) div.classList.add('selected');
            div.addEventListener('click', () => {
                state.selectedAccent = c; saveState(); applyAccent(c);
                acc.querySelectorAll('.accent-item').forEach(x => x.classList.remove('selected')); div.classList.add('selected');
            });
            acc.appendChild(div);
        });
    }

    document.querySelectorAll('input[name="settingsEffect"]').forEach(r => {
        r.checked = r.value === state.selectedEffect;
        r.addEventListener('change', () => { state.selectedEffect = r.value; saveState(); document.body.dataset.bgEffect = state.selectedEffect; });
    });
}

function checkImageExists(pngSrc, jpgSrc) {
    return new Promise(resolve => {
        const img = new Image();
        img.onload = () => resolve(pngSrc);
        img.onerror = () => {
            const img2 = new Image();
            img2.onload = () => resolve(jpgSrc);
            img2.onerror = () => resolve(null);
            img2.src = jpgSrc;
        };
        img.src = pngSrc;
    });
}

function saveState() { try { localStorage.setItem(STATE_KEY, JSON.stringify(state)); } catch(e) {} }

// Утилиты цветов
function hexToHsl(hex) {
    hex = hex.replace('#', '');
    const r = parseInt(hex.substring(0,2),16)/255, g = parseInt(hex.substring(2,4),16)/255, b = parseInt(hex.substring(4,6),16)/255;
    const max = Math.max(r,g,b), min = Math.min(r,g,b); let h, s, l = (max+min)/2;
    if (max === min) { h = s = 0; } else {
        const d = max - min; s = l > .5 ? d/(2-max-min) : d/(max+min);
        switch (max) { case r: h = ((g-b)/d + (g<b?6:0))/6; break; case g: h = ((b-r)/d + 2)/6; break; case b: h = ((r-g)/d + 4)/6; break; }
    }
    return { h: h*360, s: s*100, l: l*100 };
}
function hslToHex(h, s, l) {
    h = ((h%360)+360)%360; s = Math.max(0, Math.min(100, s))/100; l = Math.max(0, Math.min(100, l))/100;
    const c = (1 - Math.abs(2*l - 1))*s, x = c * (1 - Math.abs((h/60)%2 - 1)), m = l - c/2;
    let r, g, b;
    if (h < 60) { r = c; g = x; b = 0; } else if (h < 120) { r = x; g = c; b = 0; } else if (h < 180) { r = 0; g = c; b = x; } else if (h < 240) { r = 0; g = x; b = c; } else if (h < 300) { r = x; g = 0; b = c; } else { r = c; g = 0; b = x; }
    const toHex = v => { const hh = Math.round((v+m)*255).toString(16); return hh.length === 1 ? '0' + hh : hh; };
    return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}
function generateTonalPalette(hex) {
    const { h, s } = hexToHsl(hex); const c = (h, s, l) => hslToHex(h, s, l);
    return {
        primary: c(h, Math.min(s*.8, 80), 75), onPrimary: c(h, Math.min(s*.9, 60), 20),
        primaryContainer: c(h, Math.min(s*.7, 60), 35), onPrimaryContainer: c(h, Math.min(s*.6, 50), 90),
        secondary: c(h+20, Math.min(s*.3, 40), 75), secondaryContainer: c(h+20, Math.min(s*.3, 35), 35),
        onSecondaryContainer: c(h+20, Math.min(s*.2, 30), 90), tertiary: c(h-30, Math.min(s*.5, 60), 75),
        tertiaryContainer: c(h-30, Math.min(s*.4, 45), 35), onTertiaryContainer: c(h-30, Math.min(s*.3, 40), 90),
        surface: c(h, Math.min(s*.1, 10), 8), onSurface: c(h, Math.min(s*.1, 15), 90),
        surfaceVariant: c(h, Math.min(s*.1, 15), 25), onSurfaceVariant: c(h, Math.min(s*.1, 15), 75),
        outline: c(h, Math.min(s*.1, 15), 55), outlineVariant: c(h, Math.min(s*.1, 15), 35),
        surfaceContainer: c(h, Math.min(s*.1, 10), 14), surfaceContainerHigh: c(h, Math.min(s*.1, 10), 18),
        surfaceContainerHighest: c(h, Math.min(s*.1, 10), 22), errorContainer: c(0, 60, 30), onErrorContainer: c(0, 70, 90),
    };
}